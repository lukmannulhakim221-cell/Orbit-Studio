# Orbit Studio Website

Static website (HTML, CSS, JavaScript) untuk Orbit Studio. Tanpa build step, langsung bisa di-deploy ke Vercel.

## Struktur

```
index.html                     Halaman website (semua halaman: home, shop, product, wishlist, checkout)
assets/products/<produk>/      color-XX.webp = foto per warna, look-XX.webp = foto model
assets/banners/                Banner hero, editorial, dan Shop by Edit
assets/video/                  Video The Orbit Closet + poster
assets/favicon.svg             Ikon tab browser
```

## Maintenance mode

Website saat ini dikunci dengan halaman maintenance. Password: minta ke admin.
Setelah password benar, browser itu akan tetap terbuka (tersimpan di localStorage).

Untuk membuka website ke publik, hapus dari `index.html`:
1. Blok `<meta name="robots" content="noindex, nofollow">` sampai `</style>` maintenance di dalam `<head>`.
2. Elemen `<div id="lock">` beserta `<script>` di bawahnya, tepat setelah `<body>`.

Catatan: kunci ini hanya di sisi browser (menyembunyikan tampilan). Untuk proteksi penuh, gunakan Vercel Password Protection atau middleware.

## Yang perlu diganti sebelum live

- Nomor WhatsApp: cari `CONFIG = { whatsapp: "6281234567890" }` di `index.html`.
- Data produk ada di `const DATA = {...}` di `index.html`. Saat migrasi ke WooCommerce, bagian ini diganti dengan data dari REST API.

## Deploy

Setiap perubahan yang di-push ke branch `main` di GitHub otomatis ter-deploy ulang oleh Vercel.
